package com.example.dastak_mobile;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
